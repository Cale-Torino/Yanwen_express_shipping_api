﻿using System;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Yanwen.Online.UserDesktop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const string ServiceEndPoint = "http://online.yw56.com.cn/service_sandbox";

        private string UserId
        {
            get { return ctrlCustomerCode.Text; }
            set { ctrlCustomerCode.Text = value; }
        }

        private string Password
        {
            get { return ctrlPassword.Text; }
            set { ctrlPassword.Text = value; }
        }

        private string PostResult
        {
            get { return ctrlPostResult.Text; }
            set { ctrlPostResult.Text = value; }
        }

        private string WaybillNumber
        {
            get { return ctrlWaybillNumber.Text; }
            set { ctrlWaybillNumber.Text = value; }
        }

        private string ApiToken
        {
            get { return ctrlApiToken.Text; }
            set { ctrlApiToken.Text = value; }
        }

        private string PostBody
        {
            get { return ctrlPostBody.Text; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var url = string.Format("{0}/Users/{1}/Expresses", ServiceEndPoint, UserId);

            WebClient client = new WebClient();
            client.Headers.Add(HttpRequestHeader.Authorization, "basic " + ApiToken);
            client.Headers.Add(HttpRequestHeader.ContentType, "text/xml; charset=utf-8");

            var data = Encoding.UTF8.GetBytes(PostBody);
            var result = client.UploadData(url, "POST", data);

            PostResult = Encoding.UTF8.GetString(result);

            WaybillNumber = XDocument.Parse(PostResult).Element("CreateExpressResponseType").Element("CreatedExpress").Element("Epcode").Value;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var labelSize = "A4LLabel";
                var url = string.Format("{0}/Users/{1}/Expresses/{2}/{3}", ServiceEndPoint, UserId, WaybillNumber, labelSize);

                var client = new WebClient();
                //client.UseDefaultCredentials = true;
                client.Headers.Add(HttpRequestHeader.Authorization, "basic " + ApiToken);
                client.Headers.Add(HttpRequestHeader.ContentType, "text/xml; charset=utf-8");

                client.DownloadFile(url, saveFileDialog1.FileName);

                MessageBox.Show("保存成功！");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var url = string.Format("{0}/Common/LoginUser/{1}/{2}", ServiceEndPoint, UserId, Password);

            var client = new WebClient();
            var response = client.DownloadString(url);

            ApiToken = XDocument.Parse(response)
                .Element("LoginUserResponseType")
                .Element("User")
                .Element("ApiToken").Value;
        }

        private void btnGenerateParcel_Click(object sender, EventArgs e)
        {
            var postBody = new string[]
                                    {
                                        "<ExpressType>",
                                        string.Format("  <Epcode>{0}</Epcode>",string.Format("Test{0}", new Random().Next())),
                                        string.Format("  <Userid>{0}</Userid>",UserId),
                                        "  <Channel>中邮北京挂号小包</Channel>",
                                        "  <UserOrderNumber></UserOrderNumber>",
                                        string.Format("  <SendDate>{0}T00:00:00</SendDate>",DateTime.Now.ToString("yyyy-MM-dd")),
                                        "  <Receiver>",
                                        string.Format("    <Userid>{0}</Userid>",UserId),
                                        "    <Name>Stuart Grayling</Name>",
                                        "    <Phone>1236548</Phone>",
                                        "    <Mobile>802</Mobile>",
                                        "    <Email>jpcn@mpc.com.br</Email>",
                                        "    <Company></Company>",
                                        "    <Country>英国</Country>",
                                        "    <Postcode>RM8 2BU</Postcode>",
                                        "    <State>Essex</State>",
                                        "    <City>Dagenham</City>",
                                        "    <Address1>903 Longbridge Road</Address1>",
                                        "    <Address2>String content2</Address2>",
                                        "  </Receiver>",
                                        "  <Memo></Memo>",
                                        "  <Quantity>1</Quantity>",
                                        "  <GoodsName>",
                                        string.Format("    <Userid>{0}</Userid>",UserId),
                                        "    <NameCh>多媒体播放器</NameCh>",
                                        "    <NameEn>MedialPlayer</NameEn>",
                                        "    <Weight>213</Weight>",
                                        "    <DeclaredValue>125</DeclaredValue>",
                                        "    <DeclaredCurrency>USD</DeclaredCurrency>",
                                        "  </GoodsName>",
                                        "  <GoodsName>",
                                        string.Format("    <Userid>{0}</Userid>",UserId),
                                        "    <NameCh>多媒体播放器</NameCh>",
                                        "    <NameEn>MedialPlayer</NameEn>",
                                        "    <Weight>213</Weight>",
                                        "    <DeclaredValue>125</DeclaredValue>",
                                        "    <DeclaredCurrency>USD</DeclaredCurrency>",
                                        "  </GoodsName>",
                                        "</ExpressType>"
                                    };
            ctrlPostBody.Lines = postBody;
        }

        private void btnEasternEuropeBody_Click(object sender, EventArgs e)
        {
            var postBody = new string[]
                               {
                                   "<ExpressType>",
                                   string.Format("  <Epcode></Epcode>"),
                                   string.Format("  <Userid>{0}</Userid>", UserId),
                                   "  <Channel>燕邮宝挂号</Channel>",
                                   "  <UserOrderNumber></UserOrderNumber>",
                                   string.Format("  <SendDate>{0}T00:00:00</SendDate>",
                                                 DateTime.Now.ToString("yyyy-MM-dd")),
                                   "  <Receiver>",
                                   string.Format("    <Userid>{0}</Userid>", UserId),
                                   "    <Name>Повышева Евгения</Name>",
                                   "    <Phone>1236548</Phone>",
                                   "    <Mobile>802</Mobile>",
                                   "    <Email>jpcn@mpc.com.br</Email>",
                                   "    <Company></Company>",
                                   "    <Country>俄罗斯</Country>",
                                   "    <Postcode>127322</Postcode>",
                                   "    <State>FL</State>",
                                   "    <City>Москва</City>",
                                   "    <Address1>Улица Милашенкова, дом 20, кв. 33 Москва</Address1>",
                                   "    <Address2>String content2</Address2>",
                                   "  </Receiver>",
                                   "  <Memo></Memo>",
                                   "  <Quantity>1</Quantity>",
                                   "  <GoodsName>",
                                   string.Format("    <Userid>{0}</Userid>", UserId),
                                   "    <Weight>213</Weight>",
                                   "    <DeclaredValue>125</DeclaredValue>",
                                   "    <DeclaredCurrency>USD</DeclaredCurrency>",
                                   string.Format("    <MoreGoodsName>{0}</MoreGoodsName>",
                                                 "MedialPlayer 3" + Environment.NewLine + "ComputerLine 200" +
                                                 Environment.NewLine + "T-SHIRT 500"),
                                   "  </GoodsName>",
                                   "</ExpressType>"
                               };
            ctrlPostBody.Lines = postBody;
        }
    }
}
