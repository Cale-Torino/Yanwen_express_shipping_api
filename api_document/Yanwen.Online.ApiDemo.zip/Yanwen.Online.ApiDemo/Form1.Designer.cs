﻿namespace Yanwen.Online.UserDesktop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ctrlCustomerCode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ctrlPassword = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.ctrlPostBody = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ctrlBody = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnEasternEuropeBody = new System.Windows.Forms.Button();
            this.btnGenerateParcel = new System.Windows.Forms.Button();
            this.ctrlPostResult = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.ctrlWaybillNumber = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.ctrlApiToken = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.ctrlBody.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "客户号";
            // 
            // ctrlCustomerCode
            // 
            this.ctrlCustomerCode.Location = new System.Drawing.Point(54, 9);
            this.ctrlCustomerCode.Name = "ctrlCustomerCode";
            this.ctrlCustomerCode.Size = new System.Drawing.Size(100, 21);
            this.ctrlCustomerCode.TabIndex = 1;
            this.ctrlCustomerCode.Text = "100000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(181, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "密码";
            // 
            // ctrlPassword
            // 
            this.ctrlPassword.Location = new System.Drawing.Point(218, 9);
            this.ctrlPassword.Name = "ctrlPassword";
            this.ctrlPassword.Size = new System.Drawing.Size(100, 21);
            this.ctrlPassword.TabIndex = 3;
            this.ctrlPassword.Text = "100001";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "执行提交数据";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ctrlPostBody
            // 
            this.ctrlPostBody.Location = new System.Drawing.Point(2, 34);
            this.ctrlPostBody.Multiline = true;
            this.ctrlPostBody.Name = "ctrlPostBody";
            this.ctrlPostBody.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ctrlPostBody.Size = new System.Drawing.Size(832, 229);
            this.ctrlPostBody.TabIndex = 8;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 549);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(870, 22);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // ctrlBody
            // 
            this.ctrlBody.Controls.Add(this.tabPage1);
            this.ctrlBody.Controls.Add(this.tabPage2);
            this.ctrlBody.Location = new System.Drawing.Point(10, 33);
            this.ctrlBody.Name = "ctrlBody";
            this.ctrlBody.SelectedIndex = 0;
            this.ctrlBody.Size = new System.Drawing.Size(848, 515);
            this.ctrlBody.TabIndex = 12;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnEasternEuropeBody);
            this.tabPage1.Controls.Add(this.btnGenerateParcel);
            this.tabPage1.Controls.Add(this.ctrlPostResult);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.ctrlPostBody);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(840, 489);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "提交数据";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnEasternEuropeBody
            // 
            this.btnEasternEuropeBody.Location = new System.Drawing.Point(367, 6);
            this.btnEasternEuropeBody.Name = "btnEasternEuropeBody";
            this.btnEasternEuropeBody.Size = new System.Drawing.Size(135, 23);
            this.btnEasternEuropeBody.TabIndex = 12;
            this.btnEasternEuropeBody.Text = "生成燕文东欧小包Body";
            this.btnEasternEuropeBody.UseVisualStyleBackColor = true;
            this.btnEasternEuropeBody.Click += new System.EventHandler(this.btnEasternEuropeBody_Click);
            // 
            // btnGenerateParcel
            // 
            this.btnGenerateParcel.Location = new System.Drawing.Point(204, 6);
            this.btnGenerateParcel.Name = "btnGenerateParcel";
            this.btnGenerateParcel.Size = new System.Drawing.Size(136, 23);
            this.btnGenerateParcel.TabIndex = 11;
            this.btnGenerateParcel.Text = "生成中国邮政小包Body";
            this.btnGenerateParcel.UseVisualStyleBackColor = true;
            this.btnGenerateParcel.Click += new System.EventHandler(this.btnGenerateParcel_Click);
            // 
            // ctrlPostResult
            // 
            this.ctrlPostResult.Location = new System.Drawing.Point(2, 281);
            this.ctrlPostResult.Multiline = true;
            this.ctrlPostResult.Name = "ctrlPostResult";
            this.ctrlPostResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ctrlPostResult.Size = new System.Drawing.Size(832, 205);
            this.ctrlPostResult.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "结果";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.ctrlWaybillNumber);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(840, 489);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "下载PDF";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(202, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(97, 28);
            this.button2.TabIndex = 13;
            this.button2.Text = "执行下载PDF";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ctrlWaybillNumber
            // 
            this.ctrlWaybillNumber.Location = new System.Drawing.Point(70, 15);
            this.ctrlWaybillNumber.Name = "ctrlWaybillNumber";
            this.ctrlWaybillNumber.Size = new System.Drawing.Size(126, 21);
            this.ctrlWaybillNumber.TabIndex = 14;
            this.ctrlWaybillNumber.Text = "RC281709835CN\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "快递单号";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(324, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(97, 28);
            this.button3.TabIndex = 14;
            this.button3.Text = "获取Token";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // ctrlApiToken
            // 
            this.ctrlApiToken.Location = new System.Drawing.Point(427, 9);
            this.ctrlApiToken.Name = "ctrlApiToken";
            this.ctrlApiToken.Size = new System.Drawing.Size(421, 21);
            this.ctrlApiToken.TabIndex = 15;
            this.ctrlApiToken.Text = "MTAwMDAwOjEyMzQ1Njc4";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "pdf";
            this.saveFileDialog1.Filter = "*.pdf|PDF";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 571);
            this.Controls.Add(this.ctrlApiToken);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.ctrlBody);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.ctrlPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ctrlCustomerCode);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "燕文物流-API测试程序";
            this.ctrlBody.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ctrlCustomerCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ctrlPassword;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox ctrlPostBody;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabControl ctrlBody;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox ctrlPostResult;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ctrlWaybillNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox ctrlApiToken;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnGenerateParcel;
        private System.Windows.Forms.Button btnEasternEuropeBody;
    }
}

